'use client';
import { useEffect, useState } from 'react';
import { API_BASE } from '../../lib/api';
import { useSession } from '../../lib/auth';

export default function Dashboard() {
  const { user } = useSession();
  const [bookings, setBookings] = useState<any[]>([]);
  const [avail, setAvail] = useState<any[]>([]);
  const [slot, setSlot] = useState({ date: '', start: '09:00', end: '12:00' });
  const [status, setStatus] = useState<string | null>(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) return;
    fetch(`${API_BASE}/bookings/me`, { headers: { 'Authorization': `Bearer ${token}` } })
      .then(r => r.json()).then(setBookings).catch(()=>{});

    // try load provider availability
    if (user?.providerProfile?.id) {
      fetch(`${API_BASE}/availability/${user.providerProfile.id}`)
        .then(r => r.json()).then(setAvail).catch(()=>{});
    }
  }, [user?.providerProfile?.id]);

  const addSlot = async () => {
    if (!user) return;
    setStatus('Saving slot...');
    const token = localStorage.getItem('token')!;
    const startIso = new Date(`${slot.date}T${slot.start}:00`).toISOString();
    const endIso = new Date(`${slot.date}T${slot.end}:00`).toISOString();
    try {
      const res = await fetch(`${API_BASE}/availability`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({ start: startIso, end: endIso })
      });
      if (!res.ok) throw new Error(await res.text());
      const s = await res.json();
      setAvail([s, ...avail]);
      setStatus('Slot added.');
    } catch (e:any) {
      setStatus('Error: ' + (e?.message || 'Unknown'));
    }
  };

  const confirmBooking = async (id: string) => {
    const token = localStorage.getItem('token')!;
    await fetch(`${API_BASE}/bookings/${id}/confirm`, { method: 'POST', headers: { 'Authorization': `Bearer ${token}` } });
    setBookings(bookings.map(b => b.id === id ? { ...b, status: 'CONFIRMED' } : b));
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="md:col-span-2 space-y-4">
        <div className="card p-4">
          <div className="font-semibold">My Bookings</div>
          <div className="mt-3 space-y-2">
            {bookings.map(b => (
              <div key={b.id} className="border rounded p-3 flex items-center justify-between text-sm">
                <div>
                  <div>Status: <b>{b.status}</b></div>
                  <div>{new Date(b.start).toLocaleString()} → {new Date(b.end).toLocaleString()}</div>
                  {b.provider ? <div>Provider: {b.provider.user.name}</div> : <div>Customer: {b.customer?.name}</div>}
                  <div>Total: ${(b.totalAmount/100).toFixed(2)}</div>
                </div>
                {user?.role === 'PROVIDER' && b.status === 'PENDING' && (
                  <button className="btn btn-primary" onClick={() => confirmBooking(b.id)}>Confirm</button>
                )}
              </div>
            ))}
            {!bookings.length && <div className="text-gray-600 text-sm">No bookings yet.</div>}
          </div>
        </div>
      </div>
      <div className="space-y-4">
        {user?.role === 'PROVIDER' && (
          <div className="card p-4">
            <div className="font-semibold mb-2">Availability</div>
            <div className="grid grid-cols-1 gap-2">
              <input type="date" className="border rounded px-2 py-2" value={slot.date} onChange={e => setSlot({ ...slot, date: e.target.value })} />
              <div className="grid grid-cols-2 gap-2">
                <input type="time" className="border rounded px-2 py-2" value={slot.start} onChange={e => setSlot({ ...slot, start: e.target.value })} />
                <input type="time" className="border rounded px-2 py-2" value={slot.end} onChange={e => setSlot({ ...slot, end: e.target.value })} />
              </div>
              <button className="btn btn-primary" onClick={addSlot}>Add Slot</button>
              {status && <div className="text-xs mt-1">{status}</div>}
            </div>
            <div className="mt-3 text-sm">
              <div className="font-medium mb-1">Upcoming Slots</div>
              <ul className="list-disc ml-5">
                {avail.map(s => <li key={s.id}>{new Date(s.start).toLocaleString()} → {new Date(s.end).toLocaleString()}</li>)}
              </ul>
              {!avail.length && <div className="text-gray-600">No slots yet.</div>}
            </div>
          </div>
        )}
        <div className="card p-4 text-sm">
          <div className="font-semibold mb-2">Account</div>
          {user ? (
            <div>
              <div>Name: {user.name}</div>
              <div>Email: {user.email}</div>
              <div>Role: {user.role}</div>
            </div>
          ) : <div>Sign in to view.</div>}
        </div>
      </div>
    </div>
  );
}
