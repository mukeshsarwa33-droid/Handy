export default function Page() {
  return (
    <div className="prose max-w-2xl">
      <h1 className="text-2xl font-semibold mb-2">Trust</h1>
      <p className="text-gray-700">Trust & Safety: ID checks and background badges planned in Phase 2. Reviews require a confirmed booking. Payments are secured via Stripe when enabled.</p>
    </div>
  );
}
