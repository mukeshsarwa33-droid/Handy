export default function Page() {
  return (
    <div className="prose max-w-2xl">
      <h1 className="text-2xl font-semibold mb-2">Terms</h1>
      <p className="text-gray-700">Basic terms placeholder. You own your content; you must honor bookings; we’re a marketplace, not the employer. Full legal copy to follow.</p>
    </div>
  );
}
