'use client';
import './globals.css';
import { useSession } from '../lib/auth';

export const metadata = {
  title: process.env.APP_NAME || 'HandyHub Kelowna',
  description: 'Book trusted local handymen in Kelowna — fast.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const { user, signOut } = useSession();
  return (
    <html lang="en">
      <body>
        <header className="border-b bg-white">
          <div className="container py-4 flex items-center justify-between">
            <a href="/" className="font-semibold text-lg">{process.env.APP_NAME || 'HandyHub Kelowna'}</a>
            <nav className="space-x-4 text-sm">
              <a href="/providers">Browse Providers</a>
              <a href="/trust">Trust & Safety</a>
              <a href="/about">About</a>
              {user ? (
                <>
                  <a href="/dashboard">Dashboard</a>
                  <button onClick={signOut} className="btn">Sign out</button>
                </>
              ) : (
                <>
                  <a href="/auth/sign-in">Sign in</a>
                  <a href="/auth/sign-up" className="btn btn-primary">Sign up</a>
                </>
              )}
            </nav>
          </div>
        </header>
        <main className="container py-8">{children}</main>
        <footer className="border-t bg-white mt-12">
          <div className="container py-6 text-sm text-gray-600">
            © {new Date().getFullYear()} {process.env.APP_NAME || 'HandyHub Kelowna'} • <a href="/pricing">Pricing</a> • <a href="/contact">Contact</a> • <a href="/terms">Terms</a>
          </div>
        </footer>
      </body>
    </html>
  );
}
