export default function Page() {
  return (
    <div className="prose max-w-2xl">
      <h1 className="text-2xl font-semibold mb-2">About</h1>
      <p className="text-gray-700">We’re building the fastest way to book vetted local pros in Kelowna. We focus on clear pricing, verified profiles (Phase 2), and responsive support.</p>
    </div>
  );
}
