import CategoryGrid from '../components/CategoryGrid';
import { API_BASE } from '../lib/api';

export const dynamic = 'force-dynamic';

export default async function Page() {
  const res = await fetch(`${API_BASE}/categories`, { cache: 'no-store' });
  const categories = await res.json();
  return (
    <div className="space-y-8">
      <section className="text-center py-10">
        <h1 className="text-3xl md:text-4xl font-bold">Book trusted local pros in Kelowna</h1>
        <p className="text-gray-600 mt-2">Barbers, lawn care, painters, plumbers, electricians, mechanics, cleaners & more.</p>
        <div className="mt-5">
          <a href="/providers" className="btn btn-primary">Browse Providers</a>
        </div>
      </section>
      <section>
        <h2 className="text-xl font-semibold mb-3">Popular Categories</h2>
        <CategoryGrid categories={categories} />
      </section>
    </div>
  );
}
