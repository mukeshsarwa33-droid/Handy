export default function Page() {
  return (
    <div className="prose max-w-2xl">
      <h1 className="text-2xl font-semibold mb-2">Contact</h1>
      <p className="text-gray-700">Questions? Email support@handyhub.local (placeholder). Response within 1 business day.</p>
    </div>
  );
}
