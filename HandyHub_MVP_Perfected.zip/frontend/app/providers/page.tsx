import ProviderCard from '../../components/ProviderCard';
import { API_BASE } from '../../lib/api';

export const dynamic = 'force-dynamic';

function qs(params: Record<string, string>) {
  const u = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => v && u.set(k, v));
  const s = u.toString();
  return s ? `?${s}` : '';
}

async function fetchCategories() {
  const res = await fetch(`${API_BASE}/categories`, { cache: 'no-store' });
  return res.json();
}

export default async function ProvidersPage({ searchParams }: { searchParams: Record<string, string> }) {
  const [providers, categories] = await Promise.all([
    fetch(`${API_BASE}/providers${qs(searchParams)}`, { cache: 'no-store' }).then(r => r.json()),
    fetchCategories()
  ]);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Find a Pro</h1>

      <form className="card p-4 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
          <input name="q" placeholder="Search name, bio, location" className="border rounded px-2 py-2" defaultValue={searchParams.q || ''} />
          <input name="minRate" placeholder="Min rate" className="border rounded px-2 py-2" defaultValue={searchParams.minRate || ''} />
          <input name="maxRate" placeholder="Max rate" className="border rounded px-2 py-2" defaultValue={searchParams.maxRate || ''} />
          <button className="btn btn-primary">Apply</button>
        </div>
        <div className="flex flex-wrap gap-2 mt-2">
          {categories.map((c: any) => {
            const active = searchParams.category === c.slug;
            return <a key={c.id} href={qs({ ...searchParams, category: c.slug }) ? `/providers${qs({ ...searchParams, category: c.slug })}` : '/providers'} className={"px-3 py-1 rounded-full border text-sm " + (active ? "bg-black text-white border-black" : "bg-white")}>{c.name}</a>
          })}
          <a href="/providers" className="px-3 py-1 rounded-full border text-sm">Clear</a>
        </div>
      </form>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {providers.map((p: any) => <ProviderCard key={p.id} p={p} />)}
      </div>
      {!providers.length && <div className="text-sm text-gray-600">No providers match your filters yet.</div>}
    </div>
  );
}
