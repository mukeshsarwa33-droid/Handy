import { API_BASE } from '../../../lib/api';
import BookingWidget from '../../../components/BookingWidget';

export const dynamic = 'force-dynamic';

import SubmitReview from '../../../components/SubmitReview';

export default async function ProviderDetail({ params }: { params: { id: string } }) {
  const res = await fetch(`${API_BASE}/providers/${params.id}`, { cache: 'no-store' });
  if (!res.ok) {
    return <div className="text-red-600">Provider not found.</div>;
  }
  const p = await res.json();
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="md:col-span-2 space-y-4">
        <div className="card p-6">
          <h1 className="text-2xl font-semibold">{p.user.name}</h1>
          <div className="text-sm text-gray-600 mt-1">{p.location}</div>
          <div className="mt-3">{p.bio || 'No bio yet.'}</div>
          <div className="text-sm text-gray-600 mt-3">Categories: {p.categories.map((c: any) => c.category.name).join(' • ')}</div>
          <div className="text-sm text-gray-600 mt-1">Rate: ${p.hourlyRate}/hr</div>
        </div>
        <div className="card p-6">
          <h2 className="font-medium">Recent Reviews</h2>
          <div className="mt-2 space-y-3">
            {p.reviews.length ? p.reviews.map((r: any) => (
              <div key={r.id} className="border-b pb-2">
                <div className="text-sm">⭐ {r.rating}/5 — <span className="text-gray-600">{r.author.name}</span></div>
                <div className="text-sm mt-1">{r.comment || 'No comment'}</div>
              </div>
            )) : <div className="text-sm text-gray-600">No reviews yet.</div>}
          </div>
        </div>
        <SubmitReview providerId={p.id} />
      </div>
      <div className="space-y-4">
        <BookingWidget providerId={p.id} hourlyRate={p.hourlyRate} />
      </div>
    </div>
  );
}
