export default function Page() {
  return (
    <div className="prose max-w-2xl">
      <h1 className="text-2xl font-semibold mb-2">Pricing</h1>
      <p className="text-gray-700">Providers pay 0% launch fee for first 3 months (configurable). After that: 10% platform fee per booking or optional subscription for priority placement.</p>
    </div>
  );
}
