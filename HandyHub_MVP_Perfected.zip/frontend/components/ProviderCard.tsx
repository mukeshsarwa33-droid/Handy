type Provider = {
  id: string;
  user: { id: string; name: string };
  bio?: string;
  hourlyRate: number;
  location: string;
  categories: { category: { name: string } }[];
  reviews: { rating: number }[];
};

export default function ProviderCard({ p }: { p: Provider }) {
  const rating = p.reviews.length ? (p.reviews.reduce((a, r) => a + r.rating, 0) / p.reviews.length).toFixed(1) : 'New';
  return (
    <a href={`/providers/${p.id}`} className="card p-4 hover:shadow-md transition block">
      <div className="flex items-center justify-between">
        <div className="font-semibold">{p.user.name}</div>
        <div className="text-sm">${p.hourlyRate}/hr</div>
      </div>
      <div className="text-sm text-gray-600 mt-1">{p.location}</div>
      <div className="text-sm mt-2 line-clamp-2">{p.bio}</div>
      <div className="text-xs text-gray-500 mt-3">
        {p.categories.map(c => c.category.name).join(' • ') || 'General'}
      </div>
      <div className="text-xs mt-1">Rating: {rating}</div>
    </a>
  );
}
