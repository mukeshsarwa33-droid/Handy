'use client';
import { useState } from 'react';
import { api } from '../lib/api';

export default function BookingWidget({ providerId, hourlyRate }: { providerId: string; hourlyRate: number }) {
  const [date, setDate] = useState('');
  const [start, setStart] = useState('09:00');
  const [end, setEnd] = useState('10:00');
  const [status, setStatus] = useState<string | null>(null);

  const submit = async () => {
    setStatus('Booking...');
    try {
      const startIso = new Date(`${date}T${start}:00`).toISOString();
      const endIso = new Date(`${date}T${end}:00`).toISOString();
      const res = await api('/bookings', { method: 'POST', body: JSON.stringify({ providerId, start: startIso, end: endIso }) });
      setStatus('Booked! Total: $' + (res.booking.totalAmount / 100).toFixed(2));
    } catch (e: any) {
      setStatus('Error: ' + (e?.message || 'Unknown'));
    }
  };

  return (
    <div className="card p-4 space-y-2">
      <div className="font-medium">Book this provider</div>
      <div className="text-sm text-gray-600">Rate: ${hourlyRate}/hr</div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
        <input type="date" className="border rounded px-2 py-2" value={date} onChange={e => setDate(e.target.value)} />
        <input type="time" className="border rounded px-2 py-2" value={start} onChange={e => setStart(e.target.value)} />
        <input type="time" className="border rounded px-2 py-2" value={end} onChange={e => setEnd(e.target.value)} />
      </div>
      <button onClick={submit} className="btn btn-primary">Book</button>
      {status && <div className="text-sm mt-2">{status}</div>}
      <p className="text-xs text-gray-500">Sign in as a customer first to book.</p>
    </div>
  );
}
