type Category = { id: string; name: string; slug: string };

export default function CategoryGrid({ categories }: { categories: Category[] }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {categories.map((c) => (
        <a key={c.id} href={`/providers?category=${c.slug}`} className="card p-4 hover:shadow-md transition">
          <div className="font-medium">{c.name}</div>
          <div className="text-xs text-gray-500 mt-1">Book now</div>
        </a>
      ))}
    </div>
  );
}
