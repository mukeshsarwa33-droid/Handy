'use client';
import { useState } from 'react';
import { api } from '../lib/api';

export default function SubmitReview({ providerId }: { providerId: string }) {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [status, setStatus] = useState<string | null>(null);

  const submit = async () => {
    setStatus('Submitting...');
    try {
      await api('/reviews', { method: 'POST', body: JSON.stringify({ providerId, rating, comment }) });
      setStatus('Thanks! Your review was added.');
      setComment('');
    } catch (e: any) {
      setStatus('Error: ' + (e?.message || 'You may need a confirmed booking first.'));
    }
  };

  return (
    <div className="card p-4">
      <div className="font-medium mb-2">Leave a review</div>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
        <select className="border rounded px-2 py-2" value={rating} onChange={e => setRating(Number(e.target.value))}>
          {[1,2,3,4,5].map(n => <option key={n} value={n}>{n} Star{n>1?'s':''}</option>)}
        </select>
        <input className="md:col-span-3 border rounded px-2 py-2" placeholder="Say something helpful (optional)" value={comment} onChange={e => setComment(e.target.value)} />
      </div>
      <button className="btn btn-primary mt-2" onClick={submit}>Submit</button>
      {status && <div className="text-sm mt-2">{status}</div>}
    </div>
  );
}
