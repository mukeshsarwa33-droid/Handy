'use client';
import { useEffect, useState } from 'react';
import { API_BASE } from './api';

export function useSession() {
  const [user, setUser] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) { setLoading(false); return; }
    fetch(`${API_BASE}/auth/me`, { headers: { 'Authorization': `Bearer ${token}` } })
      .then(r => r.json()).then(d => { setUser(d.user); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const signOut = () => { localStorage.removeItem('token'); window.location.href = '/'; };
  return { user, loading, signOut };
}
