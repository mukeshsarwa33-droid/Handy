# HandyHub (Kelowna) — Phase 1 MVP

A local services marketplace for Kelowna where customers can book handymen (barber at home, lawn care, painting, plumbing, electrician, mechanic, cleaning, etc.).

## Tech Stack
- Frontend: Next.js 14 (App Router) + TypeScript + Tailwind CSS
- Backend: Node.js + Express + TypeScript + Prisma
- DB: PostgreSQL (via Docker)
- Auth: Email + Password (JWT)
- Payments: Stripe (test-mode ready; can be enabled with keys)
- Timezone: America/Vancouver

## Quick Start

### 0) Requirements
- Node 20+
- Docker + Docker Compose

### 1) Start the database
```bash
docker compose up -d
```

### 2) Backend — install, migrate, seed, run
```bash
cd backend
cp .env.example .env   # fill DB + JWT + (optional) Stripe keys
npm install
npx prisma migrate dev --name init
npm run seed
npm run dev
```

By default it runs on `http://localhost:4000`.

### 3) Frontend — install & run
```bash
cd ../frontend
cp .env.example .env   # set NEXT_PUBLIC_API_BASE=http://localhost:4000
npm install
npm run dev
```

Visit `http://localhost:3000`

### Seeded Test Accounts
- **Customer**: `customer@demo.local` / `Passw0rd!`
- **Provider**: `painter@demo.local` / `Passw0rd!` (categories: Painting, Lawn Care)
- **Admin**: `admin@demo.local` / `Passw0rd!`

### Notes
- Payments are stubbed unless Stripe keys are provided.
- Email verification & background checks are placeholders for Phase 2.
- All code is intentionally simple and well‑commented so we can iterate fast.
