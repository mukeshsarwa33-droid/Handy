import 'dotenv/config';
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  // categories
  const categories = [
    { slug: 'barber', name: 'Barber (At Home)' },
    { slug: 'lawn-care', name: 'Lawn Care' },
    { slug: 'painting', name: 'Painting' },
    { slug: 'plumbing', name: 'Plumbing' },
    { slug: 'electrical', name: 'Electrical' },
    { slug: 'mechanic', name: 'Mechanic' },
    { slug: 'cleaning', name: 'Home Cleaning' },
    { slug: 'carpentry', name: 'Carpentry' },
    { slug: 'appliance-repair', name: 'Appliance Repair' },
    { slug: 'window-cleaning', name: 'Window Cleaning' },
    { slug: 'gutter-cleaning', name: 'Gutter Cleaning' },
    { slug: 'moving-help', name: 'Moving Help' },
    { slug: 'snow-removal', name: 'Snow Removal' },
    { slug: 'it-support', name: 'IT Support' },
    { slug: 'pet-care', name: 'Dog Walking & Pet Sitting' },
    { slug: 'furniture-assembly', name: 'Furniture Assembly' }
  ];
  await prisma.category.createMany({ data: categories, skipDuplicates: true });

  // users
  const pass = await bcrypt.hash('Passw0rd!', 10);
  const customer = await prisma.user.upsert({
    where: { email: 'customer@demo.local' },
    update: {},
    create: { email: 'customer@demo.local', password: pass, name: 'Demo Customer', role: 'CUSTOMER' }
  });

  const providerUser = await prisma.user.upsert({
    where: { email: 'painter@demo.local' },
    update: {},
    create: { email: 'painter@demo.local', password: pass, name: 'Alex Painter', role: 'PROVIDER' }
  });

  const admin = await prisma.user.upsert({
    where: { email: 'admin@demo.local' },
    update: {},
    create: { email: 'admin@demo.local', password: pass, name: 'Admin', role: 'ADMIN' }
  });

  const providerProfile = await prisma.providerProfile.upsert({
    where: { userId: providerUser.id },
    update: {},
    create: {
      userId: providerUser.id,
      bio: 'Quality painting and lawn care around Kelowna. Fast, friendly, affordable.',
      hourlyRate: 45,
      location: 'Kelowna, BC',
      isVerified: true
    }
  });

  const painting = await prisma.category.findUnique({ where: { slug: 'painting' } });
  const lawn = await prisma.category.findUnique({ where: { slug: 'lawn-care' } });
  if (painting && lawn) {
    await prisma.providerCategory.createMany({
      data: [
        { providerId: providerProfile.id, categoryId: painting.id },
        { providerId: providerProfile.id, categoryId: lawn.id }
      ],
      skipDuplicates: true
    });
  }

  console.log('Seed completed');
}

main().catch(e => {
  console.error(e);
  process.exit(1);
}).finally(async () => {
  await prisma.$disconnect();
});
