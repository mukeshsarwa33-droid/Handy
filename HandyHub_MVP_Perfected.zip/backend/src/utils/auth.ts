import jwt from 'jsonwebtoken';
import { Request, Response, NextFunction } from 'express';

export interface JWTPayload {
  sub: string;
  role: 'CUSTOMER' | 'PROVIDER' | 'ADMIN';
  email: string;
}

export function signToken(payload: JWTPayload) {
  const secret = process.env.JWT_SECRET || 'dev-secret';
  return jwt.sign(payload, secret, { expiresIn: '7d' });
}

export function authRequired(roles?: Array<JWTPayload['role']>) {
  return (req: Request, res: Response, next: NextFunction) => {
    const header = req.headers.authorization;
    if (!header) return res.status(401).json({ error: 'Missing auth header' });
    const token = header.replace('Bearer ', '').trim();
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'dev-secret') as JWTPayload;
      (req as any).user = decoded;
      if (roles && roles.length && !roles.includes(decoded.role)) {
        return res.status(403).json({ error: 'Forbidden' });
      }
      next();
    } catch {
      return res.status(401).json({ error: 'Invalid token' });
    }
  };
}
