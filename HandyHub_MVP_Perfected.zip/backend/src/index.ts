import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { PrismaClient } from '@prisma/client';

import authRouter from './routes/auth';
import categoriesRouter from './routes/categories';
import providersRouter from './routes/providers';
import availabilityRouter from './routes/availability';
import bookingsRouter from './routes/bookings';
import paymentsRouter from './routes/payments';
import reviewsRouter from './routes/reviews';

const app = express();
const prisma = new PrismaClient();

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

app.get('/health', async (_req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    res.json({ ok: true, ts: new Date().toISOString() });
  } catch (e) {
    res.status(500).json({ ok: false, error: 'db' });
  }
});

app.use('/auth', authRouter);
app.use('/categories', categoriesRouter);
app.use('/providers', providersRouter);
app.use('/availability', availabilityRouter);
app.use('/bookings', bookingsRouter);
app.use('/payments', paymentsRouter);
app.use('/reviews', reviewsRouter);

const PORT = process.env.PORT ? Number(process.env.PORT) : 4000;
app.listen(PORT, () => {
  console.log(`HandyHub API running on http://localhost:${PORT}`);
});
