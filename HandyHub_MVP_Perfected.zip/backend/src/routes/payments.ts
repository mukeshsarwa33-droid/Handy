import express from 'express';
import Stripe from 'stripe';
import { prisma } from '../utils/prisma';
import { authRequired } from '../utils/auth';

const router = express.Router();
const stripeSecret = process.env.STRIPE_SECRET_KEY || '';
const stripe = stripeSecret ? new Stripe(stripeSecret, { apiVersion: '2024-06-20' }) : null;

// Create a payment intent for a booking (optional Stripe)
router.post('/intent', authRequired(['CUSTOMER']), async (req, res) => {
  if (!stripe) return res.status(400).json({ error: 'Stripe not configured' });
  const { bookingId } = req.body;
  const booking = await prisma.booking.findUnique({ where: { id: bookingId }, include: { provider: true } });
  if (!booking) return res.status(404).json({ error: 'Booking not found' });

  const intent = await stripe.paymentIntents.create({
    amount: booking.totalAmount,
    currency: 'cad',
    automatic_payment_methods: { enabled: true },
    metadata: { bookingId }
  });

  await prisma.booking.update({ where: { id: bookingId }, data: { paymentIntentId: intent.id } });
  res.json({ clientSecret: intent.client_secret });
});

export default router;
