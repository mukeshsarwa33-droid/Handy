import express from 'express';
import { prisma } from '../utils/prisma';
import bcrypt from 'bcrypt';
import { z } from 'zod';
import { signToken } from '../utils/auth';

const router = express.Router();

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  name: z.string().min(2),
  role: z.enum(['CUSTOMER', 'PROVIDER']).default('CUSTOMER'),
  hourlyRate: z.number().int().min(10).max(500).optional(),
  location: z.string().min(2).optional(),
  bio: z.string().max(500).optional(),
  categories: z.array(z.string()).optional()
});

router.post('/register', async (req, res) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json(parsed.error.flatten());

  const { email, password, name, role, hourlyRate, location, bio, categories } = parsed.data;
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) return res.status(409).json({ error: 'Email already in use' });

  const hash = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({
    data: {
      email, password: hash, name, role,
      providerProfile: role === 'PROVIDER' ? {
        create: {
          hourlyRate: hourlyRate ?? 30,
          location: location ?? 'Kelowna, BC',
          bio: bio ?? ''
        }
      } : undefined
    },
    include: { providerProfile: true }
  });

  // attach categories if provided
  if (role === 'PROVIDER' && categories?.length) {
    const cats = await prisma.category.findMany({ where: { slug: { in: categories } } });
    if (user.providerProfile) {
      await prisma.providerCategory.createMany({
        data: cats.map(c => ({ providerId: user.providerProfile!.id, categoryId: c.id })),
        skipDuplicates: true
      });
    }
  }

  const token = signToken({ sub: user.id, role: user.role as any, email: user.email });
  res.json({ token, user });
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8)
});

router.post('/login', async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json(parsed.error.flatten());

  const { email, password } = parsed.data;
  const user = await prisma.user.findUnique({ where: { email }, include: { providerProfile: true } });
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.password);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  const token = signToken({ sub: user.id, role: user.role as any, email: user.email });
  res.json({ token, user });
});

export default router;


router.get('/me', async (req, res) => {
  const header = req.headers.authorization;
  if (!header) return res.status(200).json({ user: null });
  const token = header.replace('Bearer ', '').trim();
  try {
    const decoded: any = (await import('../utils/auth')).authRequired();
  } catch {}
  // lightweight decode (no erroring)
  try {
    const jwt = (await import('jsonwebtoken')).default;
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'dev-secret') as any;
    const user = await prisma.user.findUnique({ where: { id: payload.sub }, include: { providerProfile: true } });
    return res.json({ user });
  } catch {
    return res.json({ user: null });
  }
});
