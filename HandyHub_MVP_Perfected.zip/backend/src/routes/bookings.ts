import express from 'express';
import { prisma } from '../utils/prisma';
import { authRequired } from '../utils/auth';

const router = express.Router();

// Create a booking (customer)
router.post('/', authRequired(['CUSTOMER']), async (req, res) => {
  const user = (req as any).user;
  const { providerId, start, end } = req.body;
  if (!providerId || !start || !end) return res.status(400).json({ error: 'Missing fields' });

  // check conflicts
  const s = new Date(start);
  const e = new Date(end);
  if (e <= s) return res.status(400).json({ error: 'Invalid times' });

  const provider = await prisma.providerProfile.findUnique({ where: { id: providerId } });
  if (!provider) return res.status(404).json({ error: 'Provider not found' });

  const conflict = await prisma.booking.findFirst({
    where: {
      providerId,
      status: { in: ['PENDING', 'CONFIRMED'] },
      OR: [
        { start: { lt: e }, end: { gt: s } }
      ]
    }
  });
  if (conflict) return res.status(409).json({ error: 'Time slot not available' });

  const hours = (e.getTime() - s.getTime()) / (1000 * 60 * 60);
  const totalAmount = Math.round(provider.hourlyRate * hours * 100); // cents

  const booking = await prisma.booking.create({
    data: {
      providerId,
      customerId: user.sub,
      start: s,
      end: e,
      totalAmount
    }
  });

  res.json({ booking, clientSecret: null }); // Stripe clientSecret can be added here
});

// My bookings (customer or provider)
router.get('/me', authRequired(['CUSTOMER', 'PROVIDER']), async (req, res) => {
  const user = (req as any).user;
  if (user.role === 'CUSTOMER') {
    const list = await prisma.booking.findMany({
      where: { customerId: user.sub },
      include: { provider: { include: { user: true } } },
      orderBy: { createdAt: 'desc' }
    });
    return res.json(list);
  } else {
    const profile = await prisma.providerProfile.findUnique({ where: { userId: user.sub } });
    if (!profile) return res.json([]);
    const list = await prisma.booking.findMany({
      where: { providerId: profile.id },
      include: { customer: true },
      orderBy: { createdAt: 'desc' }
    });
    return res.json(list);
  }
});

// Provider confirms a booking
router.post('/:id/confirm', authRequired(['PROVIDER']), async (req, res) => {
  const user = (req as any).user;
  const { id } = req.params;
  const profile = await prisma.providerProfile.findUnique({ where: { userId: user.sub } });
  if (!profile) return res.status(404).json({ error: 'Profile not found' });

  const booking = await prisma.booking.findUnique({ where: { id } });
  if (!booking || booking.providerId !== profile.id) return res.status(404).json({ error: 'Not found' });

  const updated = await prisma.booking.update({ where: { id }, data: { status: 'CONFIRMED' } });
  res.json(updated);
});

export default router;


// Provider marks a booking completed
router.post('/:id/complete', authRequired(['PROVIDER']), async (req, res) => {
  const user = (req as any).user;
  const { id } = req.params;
  const profile = await prisma.providerProfile.findUnique({ where: { userId: user.sub } });
  if (!profile) return res.status(404).json({ error: 'Profile not found' });

  const booking = await prisma.booking.findUnique({ where: { id } });
  if (!booking || booking.providerId !== profile.id) return res.status(404).json({ error: 'Not found' });

  const updated = await prisma.booking.update({ where: { id }, data: { status: 'COMPLETED' } });
  res.json(updated);
});
