import express from 'express';
import { prisma } from '../utils/prisma';
import { authRequired } from '../utils/auth';

const router = express.Router();

router.get('/', async (_req, res) => {
  const categories = await prisma.category.findMany({ orderBy: { name: 'asc' } });
  res.json(categories);
});

// (Admin only) Add a category
router.post('/', authRequired(['ADMIN']), async (req, res) => {
  const { name, slug } = req.body;
  if (!name || !slug) return res.status(400).json({ error: 'name and slug required' });
  const cat = await prisma.category.create({ data: { name, slug } });
  res.json(cat);
});

export default router;
