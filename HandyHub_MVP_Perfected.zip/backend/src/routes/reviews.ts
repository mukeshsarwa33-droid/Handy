import express from 'express';
import { prisma } from '../utils/prisma';
import { authRequired } from '../utils/auth';
import { z } from 'zod';

const router = express.Router();

const reviewSchema = z.object({
  providerId: z.string(),
  rating: z.number().int().min(1).max(5),
  comment: z.string().max(500).optional()
});

// Create a review (customer only)
router.post('/', authRequired(['CUSTOMER']), async (req, res) => {
  const user = (req as any).user;
  const parsed = reviewSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json(parsed.error.flatten());

  const { providerId, rating, comment } = parsed.data;

  // simple guard: allow review if customer has at least 1 completed/confirmed booking with provider
  const prior = await prisma.booking.findFirst({
    where: {
      providerId,
      customerId: user.sub,
      status: { in: ['CONFIRMED', 'COMPLETED'] }
    }
  });
  if (!prior) return res.status(403).json({ error: 'You can review after a booking is confirmed' });

  const review = await prisma.review.create({
    data: {
      providerId, rating, comment: comment || null, authorId: user.sub
    }
  });
  res.json(review);
});

export default router;
