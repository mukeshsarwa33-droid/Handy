import express from 'express';
import { prisma } from '../utils/prisma';
import { authRequired } from '../utils/auth';

const router = express.Router();

// Provider creates availability slots
router.post('/', authRequired(['PROVIDER']), async (req, res) => {
  const user = (req as any).user;
  const { start, end, isRecurring, weekday } = req.body;
  const profile = await prisma.providerProfile.findUnique({ where: { userId: user.sub } });
  if (!profile) return res.status(404).json({ error: 'Profile not found' });
  const slot = await prisma.availabilitySlot.create({
    data: {
      providerId: profile.id,
      start: new Date(start),
      end: new Date(end),
      isRecurring: !!isRecurring,
      weekday: weekday ?? null
    }
  });
  res.json(slot);
});

// Public: list availability for a provider (simple)
router.get('/:providerId', async (req, res) => {
  const { providerId } = req.params;
  const slots = await prisma.availabilitySlot.findMany({
    where: { providerId },
    orderBy: { start: 'asc' }
  });
  res.json(slots);
});

export default router;
