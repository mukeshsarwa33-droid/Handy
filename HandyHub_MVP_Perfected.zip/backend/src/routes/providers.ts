import express from 'express';
import { prisma } from '../utils/prisma';
import { authRequired } from '../utils/auth';

const router = express.Router();

// List providers (with filters)
router.get('/', async (req, res) => {
  const { category, q, minRate, maxRate } = req.query as Record<string, string>;
  const where: any = {};
  if (category) {
    where.categories = { some: { category: { slug: category } } };
  }
  if (minRate || maxRate) {
    where.hourlyRate = {};
    if (minRate) where.hourlyRate.gte = Number(minRate);
    if (maxRate) where.hourlyRate.lte = Number(maxRate);
  }
  if (q) {
    where.OR = [
      { bio: { contains: q, mode: 'insensitive' } },
      { location: { contains: q, mode: 'insensitive' } },
      { user: { name: { contains: q, mode: 'insensitive' } } }
    ];
  }
  const providers = await prisma.providerProfile.findMany({
    where,
    include: {
      user: { select: { id: true, name: true } },
      categories: { include: { category: true } },
      reviews: true
    },
    orderBy: { createdAt: 'desc' }
  });
  res.json(providers);
});

// Provider detail
router.get('/:id', async (req, res) => {
  const id = req.params.id;
  const provider = await prisma.providerProfile.findUnique({
    where: { id },
    include: {
      user: { select: { id: true, name: true } },
      categories: { include: { category: true } },
      reviews: {
        include: { author: { select: { id: true, name: true } } },
        orderBy: { createdAt: 'desc' }
      },
      availability: true
    }
  });
  if (!provider) return res.status(404).json({ error: 'Not found' });
  res.json(provider);
});

// Provider updates their profile
router.post('/me', authRequired(['PROVIDER']), async (req, res) => {
  const user = (req as any).user;
  const { bio, hourlyRate, location, categories } = req.body;

  const profile = await prisma.providerProfile.findUnique({ where: { userId: user.sub } });
  if (!profile) return res.status(404).json({ error: 'Profile not found' });

  const updated = await prisma.providerProfile.update({
    where: { id: profile.id },
    data: {
      bio: bio ?? undefined,
      hourlyRate: hourlyRate ? Number(hourlyRate) : undefined,
      location: location ?? undefined
    }
  });

  if (Array.isArray(categories)) {
    const cats = await prisma.category.findMany({ where: { slug: { in: categories } } });
    await prisma.providerCategory.deleteMany({ where: { providerId: profile.id } });
    await prisma.providerCategory.createMany({
      data: cats.map(c => ({ providerId: profile.id, categoryId: c.id }))
    });
  }

  res.json(updated);
});

export default router;
